<?php
echo '<h2>Rezept suche</h2><br>';

if(isset($_POST['suche']))
{
$from=$_POST['From'];
$to=$_POST['To'];

$query='select id, beschreibung
from zubereitung zb
where zub_bereitgestellt_am between ? and ?
order by zb.id';

$array=array($from,$to);

if(!$to)
{
    $query='select id, beschreibung
    from zubereitung zb
    where zub_bereitgestellt_am > ?
    order by zb.id';
    $array=array($from);
}

$query2='select zbe.zubein_menge as Menge,
e.name as Einheit,
z.name as Zutat
from zubereitung_einheit zbe, 
zutat_einheit ze, 
einheit e, 
zutat z 
where zbe.zub_id =?
and zbe.zuei_id=ze.zuei_id 
and ze.zut_id=z.id 
and ze.ein_id=e.id';

global $conn;
try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    $meta=array();
    if($stmt->rowCount()>0)
    {
    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo 'Rezeptnummer '.$row[0].': '.$row[1].'<br>';
        $array2=array($row[0]);

        $stmt2= $conn->prepare($query2);
        $stmt2->execute($array2);
    
        $meta2=array();
        echo '<table class="table">
        <tr>';
        $colCount=$stmt2->columnCount();

        for($i =0; $i<$colCount;$i++)
        {
            $meta2[]= $stmt2->getColumnMeta($i);
            echo '<th>'.$meta2[$i]['name'].'</th>';
        }
        echo '</tr>';

        while($row2=$stmt2->fetch(PDO::FETCH_NUM))
        {
            echo '<tr>';
            foreach($row2 as $r)
            {
                echo '<td>'.$r.'</td>';
            }
            echo '</tr>';
        }

        echo '</table>';
    }
}
else
{
    echo '<h2>Es konnte kein Rezept gefunden werden</h>';
}

} catch(Exception $e)
{
    echo "Error - Rezept: " .$e->getCode().$e->getMessage();
}
}else if(isset($_POST['sucheMonth']))
{
$month=$_POST['month'];
$varMonth=$_POST['varMonth'];

$query='select id, beschreibung
from zubereitung zb
where month(zub_bereitgestellt_am) = ?
and year(zub_bereitgestellt_am)=year(now())
order by zb.id';

switch ($month) {
    case "lastMonth":
        if(date("m")==1)
        {
            $varMonth=12;
        }
        else
        {
            $varMonth=date("m")-1;
        }
      break;
    case "currMonth":
        $varMonth=date("m");
      break;
    case "varMonth":
        $varMonth=$_POST['varMonth'];
      break;
    default:
    echo "radio button is invalide";
  }

  $array=array($varMonth);

  $query2='select zbe.zubein_menge as Menge,
  e.name as Einheit,
  z.name as Zutat
  from zubereitung_einheit zbe, 
  zutat_einheit ze, 
  einheit e, 
  zutat z 
  where zbe.zub_id =?
  and zbe.zuei_id=ze.zuei_id 
  and ze.zut_id=z.id 
  and ze.ein_id=e.id';

global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    $meta=array();
    if($stmt->rowCount()>0)
    {
    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo 'Rezeptnummer '.$row[0].': '.$row[1].'<br>';
        $array2=array($row[0]);

        $stmt2= $conn->prepare($query2);
        $stmt2->execute($array2);
    
        $meta2=array();
        echo '<table class="table">
        <tr>';
        $colCount=$stmt2->columnCount();

        for($i =0; $i<$colCount;$i++)
        {
            $meta2[]= $stmt2->getColumnMeta($i);
            echo '<th>'.$meta2[$i]['name'].'</th>';
        }
        echo '</tr>';

        while($row2=$stmt2->fetch(PDO::FETCH_NUM))
        {
            echo '<tr>';
            foreach($row2 as $r)
            {
                echo '<td>'.$r.'</td>';
            }
            echo '</tr>';
        }

        echo '</table>';
    }
}
else
{
    echo '<h2>Es konnte kein Rezept gefunden werden</h>';
}

} catch(Exception $e)
{
    echo "Error - Rezept: " .$e->getCode().$e->getMessage();
}
}else
{//formular anzeigen
    ?>
    <form method="post">
        <h3>Rezepte nach bereitstellungszeitraum durchsuchen</h3><br>
        <div class="mb-3">
            <label for="From" class="form-label">Zeitraum von:</label>
            <input type="date" class="form-control" id="From" name="From" required>
        </div>
        <div class="mb-3">
            <label for="To" class="form-label">Zeitraum bis (kann ausgelesen werden):</label>
            <input type="date" class="form-control" id="To" name="To">
        </div>
        <input type ="submit" class="btn btn-success" name="suche" value="suchen"><br>
    </form>
    <form method="post">
        <h3>Oder wählen sie aus folgenden optionen</h3><br>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="month" id="lastMonth" value="lastMonth">
            <label class="form-check-label" for="lastMonth">
                letzter Monat
            </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="month" id="currMonth" value="currMonth">
            <label class="form-check-label" for="currMonth">
            laufender Monat
        </label>
        </div>
        <div class="form-check">
            <input class="form-check-input" type="radio" name="month" id="varMonth" value="varMonth" checked>
            <label class="form-check-label" for="varMonth">
            <input type="number" id="varMonth" name="varMonth" min="1" max="12" value="1"> Monat des laufenden jahres angeben
        </label>
        </div>
        <input type ="submit" class="btn btn-success" name="sucheMonth" value="suchen"><br>
    </form>
    <?php
}           
