<?php
echo '<h2>Rezept suche</h><br>';

if(isset($_POST['suche']))
{
$rezept=$_POST['rezept'];

$query='select * from rezeptname where name like ?';

$array=array("%$rezept%");

global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    if($stmt->rowCount()>0)
    {
        $meta=array();
        echo 'Anzahl gefundener Rezepte für <b>'.$rezept.'</b>: '.$stmt->rowCount().'<br>';
        ?>
        <form class="d-flex" method="post">
        <?php

        echo '<label for="rezeptErg">Ergebnisliste der Suche:</label>';

        echo '<select name="rezeptErg" id="rezeptErg">';

        while($row=$stmt->fetch(PDO::FETCH_NUM))
        {
            echo '<option value='.$row[0].'>'.$row[1].'</option>';
        }
        echo '</select>';

        ?>
            <input type ="submit" class="btn btn-success" name="anzeigen" value="anzeigen">
        </form>
        <?php
    }
    else
    {
        echo '<h2>Es konnte kein Rezept mit dem schluesselwort '.$rezept.' gefunden werden</h>';
    }

} catch(Exception $e)
{
    echo "Error - Rezept: " .$e->getCode().$e->getMessage();
}
}else if(isset($_POST['anzeigen']))
{
$rezeptErg=$_POST['rezeptErg'];

$query='select id, beschreibung
from zubereitung zb
where zb.rez_id=?
order by zb.id';

$query2='select zbe.zubein_menge as Menge,
e.name as Einheit,
z.name as Zutat
from zubereitung_einheit zbe, 
zutat_einheit ze, 
einheit e, 
zutat z 
where zbe.zub_id =?
and zbe.zuei_id=ze.zuei_id 
and ze.zut_id=z.id 
and ze.ein_id=e.id';

$array=array($rezeptErg);

global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    $meta=array();

    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo 'Rezeptnummer '.$row[0].': '.$row[1].'<br>';
        $array2=array($row[0]);

        $stmt2= $conn->prepare($query2);
        $stmt2->execute($array2);
    
        $meta2=array();
        echo '<table class="table">
        <tr>';
        $colCount=$stmt2->columnCount();

        for($i =0; $i<$colCount;$i++)
        {
            $meta2[]= $stmt2->getColumnMeta($i);
            echo '<th>'.$meta2[$i]['name'].'</th>';
        }
        echo '</tr>';

        while($row2=$stmt2->fetch(PDO::FETCH_NUM))
        {
            echo '<tr>';
            foreach($row2 as $r)
            {
                echo '<td>'.$r.'</td>';
            }
            echo '</tr>';
        }

        echo '</table>';
    }

} catch(Exception $e)
{
    echo "Error - Rezept: " .$e->getCode().$e->getMessage();
}
}else
{//formular anzeigen
    ?>
    <form class="d-flex" method="post">
        <input type="text" class="form-control me-2"  id="rezept" name="rezept"
            placeholder="z.b. kuchen" required>
        <input type ="submit" class="btn btn-success" name="suche" value="suchen">
    </form>
    <?php
}           
