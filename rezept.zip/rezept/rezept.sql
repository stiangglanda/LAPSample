-- MySQL Workbench Forward Engineering

SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='ONLY_FULL_GROUP_BY,STRICT_TRANS_TABLES,NO_ZERO_IN_DATE,NO_ZERO_DATE,ERROR_FOR_DIVISION_BY_ZERO,NO_ENGINE_SUBSTITUTION';

-- -----------------------------------------------------
-- Schema rezept
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `rezept` ;

-- -----------------------------------------------------
-- Schema rezept
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `rezept` DEFAULT CHARACTER SET utf8 ;
USE `rezept` ;

-- -----------------------------------------------------
-- Table `rezept`.`rezeptname`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`rezeptname` ;

CREATE TABLE IF NOT EXISTS `rezept`.`rezeptname` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE INDEX `name_UNIQUE` (`name` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rezept`.`zubereitung`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`zubereitung` ;

CREATE TABLE IF NOT EXISTS `rezept`.`zubereitung` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `beschreibung` VARCHAR(200) NOT NULL,
  `rez_id` INT NOT NULL,
  `zub_bereitgestellt_am` DATETIME NOT NULL DEFAULT now(),
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rezept`.`zutat`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`zutat` ;

CREATE TABLE IF NOT EXISTS `rezept`.`zutat` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rezept`.`einheit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`einheit` ;

CREATE TABLE IF NOT EXISTS `rezept`.`einheit` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `name` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rezept`.`zutat_einheit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`zutat_einheit` ;

CREATE TABLE IF NOT EXISTS `rezept`.`zutat_einheit` (
  `zut_id` INT NOT NULL,
  `ein_id` INT NOT NULL,
  `zuei_id` INT NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`zuei_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `rezept`.`zubereitung_einheit`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `rezept`.`zubereitung_einheit` ;

CREATE TABLE IF NOT EXISTS `rezept`.`zubereitung_einheit` (
  `zub_id` INT NOT NULL,
  `zuei_id` INT NOT NULL,
  `zubein_menge` INT NOT NULL,
  PRIMARY KEY (`zub_id`, `zuei_id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Data for table `rezept`.`rezeptname`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`rezeptname` (`id`, `name`) VALUES (1, 'Marmorkuchen');
INSERT INTO `rezept`.`rezeptname` (`id`, `name`) VALUES (2, 'Schnitzerl');
INSERT INTO `rezept`.`rezeptname` (`id`, `name`) VALUES (3, 'Wiener Schnitzerl');

COMMIT;


-- -----------------------------------------------------
-- Data for table `rezept`.`zubereitung`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`zubereitung` (`id`, `beschreibung`, `rez_id`, `zub_bereitgestellt_am`) VALUES (1, 'Mischen Sie alle Zutaten zu einem Teig', 1, DEFAULT);
INSERT INTO `rezept`.`zubereitung` (`id`, `beschreibung`, `rez_id`, `zub_bereitgestellt_am`) VALUES (2, 'Salzen, nicht Klopfen sondern drücken', 2, DEFAULT);
INSERT INTO `rezept`.`zubereitung` (`id`, `beschreibung`, `rez_id`, `zub_bereitgestellt_am`) VALUES (3, 'Verwenden Sie extra dünn geschnittene Filetschnitten', 3, DEFAULT);
INSERT INTO `rezept`.`zubereitung` (`id`, `beschreibung`, `rez_id`, `zub_bereitgestellt_am`) VALUES (4, 'Zuerst Eiklar steif schlagen, dann Mehl langsam untermischen usw', 1, DEFAULT);

COMMIT;


-- -----------------------------------------------------
-- Data for table `rezept`.`zutat`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`zutat` (`id`, `name`) VALUES (2, 'Eier');
INSERT INTO `rezept`.`zutat` (`id`, `name`) VALUES (4, 'Kakaopulver');
INSERT INTO `rezept`.`zutat` (`id`, `name`) VALUES (1, 'Mehl');
INSERT INTO `rezept`.`zutat` (`id`, `name`) VALUES (3, 'Salz');

COMMIT;


-- -----------------------------------------------------
-- Data for table `rezept`.`einheit`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`einheit` (`id`, `name`) VALUES (2, 'dag');
INSERT INTO `rezept`.`einheit` (`id`, `name`) VALUES (4, 'kg');
INSERT INTO `rezept`.`einheit` (`id`, `name`) VALUES (1, 'Prise');
INSERT INTO `rezept`.`einheit` (`id`, `name`) VALUES (3, 'Stück');

COMMIT;


-- -----------------------------------------------------
-- Data for table `rezept`.`zutat_einheit`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`zutat_einheit` (`zut_id`, `ein_id`, `zuei_id`) VALUES (1, 2, 1);
INSERT INTO `rezept`.`zutat_einheit` (`zut_id`, `ein_id`, `zuei_id`) VALUES (1, 4, 2);
INSERT INTO `rezept`.`zutat_einheit` (`zut_id`, `ein_id`, `zuei_id`) VALUES (2, 3, 3);
INSERT INTO `rezept`.`zutat_einheit` (`zut_id`, `ein_id`, `zuei_id`) VALUES (3, 1, 4);
INSERT INTO `rezept`.`zutat_einheit` (`zut_id`, `ein_id`, `zuei_id`) VALUES (4, 2, 5);

COMMIT;


-- -----------------------------------------------------
-- Data for table `rezept`.`zubereitung_einheit`
-- -----------------------------------------------------
START TRANSACTION;
USE `rezept`;
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (1, 1, 50);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (1, 3, 4);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (1, 4, 1);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (1, 5, 20);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (2, 1, 20);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (2, 3, 2);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (2, 4, 3);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (3, 1, 20);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (4, 4, 1);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (4, 5, 25);
INSERT INTO `rezept`.`zubereitung_einheit` (`zub_id`, `zuei_id`, `zubein_menge`) VALUES (4, 1, 75);

COMMIT;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
