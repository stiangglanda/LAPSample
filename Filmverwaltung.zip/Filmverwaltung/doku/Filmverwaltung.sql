-- 31.5.2023
-- Leander Kieweg
-- MySQL Workbench Forward Engineering
-- -----------------------------------------------------
-- Schema Filmverwaltung
-- -----------------------------------------------------
DROP SCHEMA IF EXISTS `Filmverwaltung` ;

-- -----------------------------------------------------
-- Schema Filmverwaltung
-- -----------------------------------------------------
CREATE SCHEMA IF NOT EXISTS `Filmverwaltung` DEFAULT CHARACTER SET utf8 ;
USE `Filmverwaltung` ;

-- -----------------------------------------------------
-- Table `Filmverwaltung`.`produktionsfirma`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Filmverwaltung`.`produktionsfirma` ;

CREATE TABLE IF NOT EXISTS `Filmverwaltung`.`produktionsfirma` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `Bezeichnung` VARCHAR(45) NOT NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Filmverwaltung`.`Film`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Filmverwaltung`.`Film` ;

CREATE TABLE IF NOT EXISTS `Filmverwaltung`.`Film` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `Titel` VARCHAR(100) NOT NULL,
  `Erscheinungsdatum` DATE NOT NULL DEFAULT now(),
  `produktionsfirma_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Film_produktionsfirma_idx` (`produktionsfirma_id` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Filmverwaltung`.`Land`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Filmverwaltung`.`Land` ;

CREATE TABLE IF NOT EXISTS `Filmverwaltung`.`Land` (
  `id` INT NOT NULL,
  `land` VARCHAR(45) NULL,
  PRIMARY KEY (`id`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Filmverwaltung`.`Schauspieler`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Filmverwaltung`.`Schauspieler` ;

CREATE TABLE IF NOT EXISTS `Filmverwaltung`.`Schauspieler` (
  `id` INT NOT NULL,
  `vorname` VARCHAR(45) NOT NULL,
  `nachname` VARCHAR(45) NOT NULL,
  `Land_id` INT NOT NULL,
  PRIMARY KEY (`id`),
  INDEX `fk_Schauspieler_Land1_idx` (`Land_id` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `Filmverwaltung`.`Schauspieler_Film`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `Filmverwaltung`.`Schauspieler_Film` ;

CREATE TABLE IF NOT EXISTS `Filmverwaltung`.`Schauspieler_Film` (
  `Schauspieler_id` INT NOT NULL,
  `Film_id` INT NOT NULL,
  PRIMARY KEY (`Schauspieler_id`, `Film_id`),
  INDEX `fk_Schauspieler_has_Film_Film1_idx` (`Film_id` ASC) VISIBLE,
  INDEX `fk_Schauspieler_has_Film_Schauspieler1_idx` (`Schauspieler_id` ASC) VISIBLE)
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Data for table `Filmverwaltung`.`produktionsfirma`
-- -----------------------------------------------------
START TRANSACTION;
USE `Filmverwaltung`;
INSERT INTO `Filmverwaltung`.`produktionsfirma` (`id`, `Bezeichnung`) VALUES (1, 'Bavaria Filmstudios');
INSERT INTO `Filmverwaltung`.`produktionsfirma` (`id`, `Bezeichnung`) VALUES (2, 'Great American Films');
INSERT INTO `Filmverwaltung`.`produktionsfirma` (`id`, `Bezeichnung`) VALUES (3, 'Warner Brothers');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Filmverwaltung`.`Film`
-- -----------------------------------------------------
START TRANSACTION;
USE `Filmverwaltung`;
INSERT INTO `Filmverwaltung`.`Film` (`id`, `Titel`, `Erscheinungsdatum`, `produktionsfirma_id`) VALUES (1, 'Dirty Dancing', DEFAULT, 1);
INSERT INTO `Filmverwaltung`.`Film` (`id`, `Titel`, `Erscheinungsdatum`, `produktionsfirma_id`) VALUES (2, 'Die Welle', DEFAULT, 2);
INSERT INTO `Filmverwaltung`.`Film` (`id`, `Titel`, `Erscheinungsdatum`, `produktionsfirma_id`) VALUES (3, 'Casanova', DEFAULT, 3);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Filmverwaltung`.`Land`
-- -----------------------------------------------------
START TRANSACTION;
USE `Filmverwaltung`;
INSERT INTO `Filmverwaltung`.`Land` (`id`, `land`) VALUES (1, 'USA');
INSERT INTO `Filmverwaltung`.`Land` (`id`, `land`) VALUES (2, 'Deutschland');
INSERT INTO `Filmverwaltung`.`Land` (`id`, `land`) VALUES (3, 'Österreich');

COMMIT;


-- -----------------------------------------------------
-- Data for table `Filmverwaltung`.`Schauspieler`
-- -----------------------------------------------------
START TRANSACTION;
USE `Filmverwaltung`;
INSERT INTO `Filmverwaltung`.`Schauspieler` (`id`, `vorname`, `nachname`, `Land_id`) VALUES (1, 'Leonardo', 'Dicaprio', 1);
INSERT INTO `Filmverwaltung`.`Schauspieler` (`id`, `vorname`, `nachname`, `Land_id`) VALUES (2, 'Samuel', 'jackson', 1);
INSERT INTO `Filmverwaltung`.`Schauspieler` (`id`, `vorname`, `nachname`, `Land_id`) VALUES (3, 'dwane', 'johnson', 1);

COMMIT;


-- -----------------------------------------------------
-- Data for table `Filmverwaltung`.`Schauspieler_Film`
-- -----------------------------------------------------
START TRANSACTION;
USE `Filmverwaltung`;
INSERT INTO `Filmverwaltung`.`Schauspieler_Film` (`Schauspieler_id`, `Film_id`) VALUES (1, 1);
INSERT INTO `Filmverwaltung`.`Schauspieler_Film` (`Schauspieler_id`, `Film_id`) VALUES (2, 2);
INSERT INTO `Filmverwaltung`.`Schauspieler_Film` (`Schauspieler_id`, `Film_id`) VALUES (3, 3);

COMMIT;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
