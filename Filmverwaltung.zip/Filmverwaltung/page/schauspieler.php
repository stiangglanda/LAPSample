<?php
echo '<h2>Schauspieler suche</h><br>';

if(isset($_POST['suche']))
{
$schauspieler=$_POST['schauspieler'];

$query=' select concat(s.vorname," ", s.nachname) as schauspieler,
l.land as herkunftsland,
f.Titel, 
f.Erscheinungsdatum, 
pf.bezeichnung as produktionsfirma  
from schauspieler s,
schauspieler_film sf,
film f,
produktionsfirma pf,
land l
where s.id=sf.schauspieler_id
and sf.film_id=f.id
and f.produktionsfirma_id=pf.id
and l.id=s.land_id
and concat(s.vorname," ", s.nachname) like ?';

$array=array("%$schauspieler%");

global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    if($stmt->rowCount()>0)
    {
        $meta=array();
        echo 'Anzahl gefundene Filmtitel für <b>'.$schauspieler.'</b>: '.$stmt->rowCount();
        echo '<table class="table">
        <tr>';
        $colCount=$stmt->columnCount();
    
        for($i =0; $i<$colCount;$i++)
        {
            $meta[]= $stmt->getColumnMeta($i);
            echo '<th>'.$meta[$i]['name'].'</th>';
        }
        echo '</tr>';
    
        while($row=$stmt->fetch(PDO::FETCH_NUM))
        {
            echo '<tr>';
            foreach($row as $r)
            {
                echo '<td>'.$r.'</td>';
            }
            echo '</tr>';
        }
    
        echo '</table>';
    }
    else
    {
        echo '<h2>Es konnte kein film mit dem Schauspieler '.$schauspieler.' gefunden werden</h>';
    }

} catch(Exception $e)
{
    echo "Error - Schauspieler: " .$e->getCode().$e->getMessage();
}
}else
{//formular anzeigen
    ?>
    <form class="d-flex" method="post">
        <input type="text" class="form-control me-2"  id="schauspieler" name="schauspieler"
            placeholder="z.b. Leonardo Dicaprio" required>
        <input type ="submit" class="btn btn-success" name="suche" value="suchen">
    </form>
    <?php
}           
