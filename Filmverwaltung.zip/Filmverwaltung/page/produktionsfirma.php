<?php
echo '<h2>Produktionsfirma suche</h><br>';

if(isset($_POST['suche']))
{
$produktionsfirma=$_POST['produktionsfirma'];

$query='select f.titel as Titel, 
f.Erscheinungsdatum, 
pf.bezeichnung as produktionsfirma 
from produktionsfirma pf, film f 
where pf.id=f.produktionsfirma_id 
and pf.bezeichnung like ?
order by f.Erscheinungsdatum desc';

$array=array("%$produktionsfirma%");

global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute($array);

    if($stmt->rowCount()>0)
    {
        $meta=array();
        echo 'Anzahl gefundene Filmtitel für <b>'.$produktionsfirma.'</b>: '.$stmt->rowCount();
        echo '<table class="table">
        <tr>';
        $colCount=$stmt->columnCount();
    
        for($i =0; $i<$colCount;$i++)
        {
            $meta[]= $stmt->getColumnMeta($i);
            echo '<th>'.$meta[$i]['name'].'</th>';
        }
        echo '</tr>';
    
        while($row=$stmt->fetch(PDO::FETCH_NUM))
        {
            echo '<tr>';
            foreach($row as $r)
            {
                echo '<td>'.$r.'</td>';
            }
            echo '</tr>';
        }
    
        echo '</table>';
    }
    else
    {
        echo '<h2>Produktionsfirma nicht gefunden</h>';
    }

} catch(Exception $e)
{
    echo "Error - Produktionsfirma: " .$e->getCode().$e->getMessage();
}
}else
{//formular anzeigen
    ?>
    <form class="d-flex" method="post">
        <input type="text" class="form-control me-2"  id="produktionsfirma" name="produktionsfirma"
            placeholder="z.b. Warner">
        <input type ="submit" class="btn btn-success" name="suche" value="suchen">
        <input type="reset" class="btn btn-danger" name="cancel" value="abbrechen"/>
        <input type="button" class="btn btn-primary" name="home" value="zurück" onClick="document.location.href='http://localhost/Filmverwaltung/?seite=home'" />
    </form>
    <?php
}           
