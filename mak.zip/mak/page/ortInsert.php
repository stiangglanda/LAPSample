<?php
echo '<h1>Neuen Ort/Neue Stadt einfügen</h1>';

if(isset($_POST['save']))
{
$ort=$_POST['ort_name'];
$plz=$_POST['plz'];

$insertOrtStmt='insert into ort(ort_name) values(?)';
$insertOrtPlzStmt='insert into ort_plz(ort_id, plz_id) values(?, ?)';

try
{
    $array=array($ort);
    $stmt=makeStatement($insertOrtStmt,$array);
    $ortId=$conn->lastInsertId();

    $array=array($ortId,$plz);
    $stmt2=makeStatement($insertOrtPlzStmt,$array);
    echo '<h3>Ort wurde hinzugefügt</h3>';
    $query='select ort_name as ort, plz_nr as plz from ort o, ort_plz op, plz p where o.ort_id=op.ort_id and op.plz_id=p.plz_id';
    makeTableConsiderLastInsert($query,$ort);

}catch (Exception $e)
{
    switch ($e->getCode()) {
        case 23000:
            echo '<h4>Ort: '.$ort.' existiert bereits!</h4>';

            $query='select ort_name as ort, plz_nr as plz from ort o, ort_plz op, plz p where o.ort_id=op.ort_id and op.plz_id=p.plz_id';
            makeTableConsiderLastInsert($query,  $ort);
            break;
        
        default:
            echo 'Error - Ort: '.$e->getCode().': '.$e->getMessage().'<br>';
            break;
    }
}
}else
{//formular anzeigen
    ?>
    <form method="post">
        <div class="mb-3">
            <label for="ort_name" class="form-label">Ort-/Stadtname:</label>
            <input type="text" class="form-control" id="ort_name" name="ort_name"
            placeholder="z.b. Wien" required>
        </div>
        <div class="mb-3">
            <label for="plz" class="form-label">PLZ:</label>
            <?php
            $query='select plz_id, plz_nr from plz order by plz_nr asc';

            $stmt=$conn->prepare($query);
            $stmt->execute();
            echo '<br><select class="form-control" id="plz" name="plz">';
            while($row=$stmt->fetch(PDO::FETCH_NUM))
            {
                echo '<option value="'.$row[0].'">'.$row[1];
            }
            echo '</select><br>';
        ?>
        </div>
        <input type ="submit" class="btn btn-success" name="save" value="speichern"><br>
    </form>
    <?php
}           
