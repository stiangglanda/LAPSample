<?php
function makeTableConsiderLastInsert($query)
{
    global $conn;
    $lastInsert=$conn->lastInsertId();
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute();

    $meta=array();
    echo '<table class="table">
    <tr>';
    $colCount=$stmt->columnCount();

    for($i =0; $i<$colCount;$i++)
    {
        $meta[]= $stmt->getColumnMeta($i);
        echo '<th>'.$meta[$i]['name'].'</th>';
    }
    echo '</tr>';

    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo '<tr>';
        foreach($row as $r)
        {
            if($row[0]==$lastInsert)
            {
                echo '<td><b>'.$r.'<b></td>';
            }
            else
            {
                echo '<td>'.$r.'</td>';
            }
        }
        echo '</tr>';
    }

    echo '</table>';
} catch(Exception $e)
{
    echo "Error - Tabelle Adressen: " .$e->getCode().$e->getMessage();
}
}

function makeTablewithButtons($query,$db)
{
    global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute();

    $meta=array();
    echo '<table class="table">
    <tr>';
    $colCount=$stmt->columnCount();

    for($i =0; $i<$colCount;$i++)
    {
        $meta[]= $stmt->getColumnMeta($i);
        echo '<th>'.$meta[$i]['name'].'</th>';
    }
    echo '</tr>';

    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo '<tr>';
        echo '<form method="post">';
        foreach($row as $r)
        {
            echo '<td>'.$r.'</td>';
        }
        echo '<input type="hidden" id="db" name="db" value='.$db.'>';
        echo '<input type="hidden" id="table" name="table" value='.$row[0].'>';
        echo '<td><input class="btn btn-primary btn-lg" type="submit" name="describe" value="describe"></td>';
        echo '<td><input class="btn btn-primary btn-lg" type="submit" name="content" value="content"></td>';
        echo '</form>';
        echo '</tr>';
    }

    echo '</table>';
} catch(Exception $e)
{
    echo "Error - Tabelle Adressen: " .$e->getCode().$e->getMessage();
}
}

function makeTablewithButton($query)
{
    global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute();

    $meta=array();
    echo '<table class="table">
    <tr>';
    $colCount=$stmt->columnCount();

    for($i =0; $i<$colCount;$i++)
    {
        $meta[]= $stmt->getColumnMeta($i);
        echo '<th>'.$meta[$i]['name'].'</th>';
    }
    echo '</tr>';

    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo '<tr>';
        echo '<form method="post">';
        foreach($row as $r)
        {
            echo '<td>'.$r.'</td>';
        }
        echo '<input type="hidden" id="db" name="db" value='.$row[0].'>';
        echo '<td><input class="btn btn-primary btn-lg" type="submit" name="send" value="auswahl"></td>';
        echo '</form>';
        echo '</tr>';
    }

    echo '</table>';
} catch(Exception $e)
{
    echo "Error - Tabelle Adressen: " .$e->getCode().$e->getMessage();
}
}

function makeTable($query)
{
    global $conn;
    try{
    $stmt= $conn->prepare($query);
    $stmt->execute();

    $meta=array();
    echo '<table class="table">
    <tr>';
    $colCount=$stmt->columnCount();

    for($i =0; $i<$colCount;$i++)
    {
        $meta[]= $stmt->getColumnMeta($i);
        echo '<th>'.$meta[$i]['name'].'</th>';
    }
    echo '</tr>';

    while($row=$stmt->fetch(PDO::FETCH_NUM))
    {
        echo '<tr>';
        foreach($row as $r)
        {
            echo '<td>'.$r.'</td>';
        }
        echo '</tr>';
    }

    echo '</table>';
} catch(Exception $e)
{
    echo "Error - Tabelle Adressen: " .$e->getCode().$e->getMessage();
}
}

function makeStatement($query, $executeArray=NULL)
{
    global $conn;
    $stmt=$conn->prepare($query);
    $stmt->execute($executeArray);
    return $stmt;
}