<?php
echo '<h2>strasseinsert</h>';

if(isset($_POST['send']))
{//Daten Speichern
$db=$_POST['db'];

$query1='use '.$db;
$query2='show tables';

try
{
    $stmt=makeStatement($query1);
    makeTablewithButtons($query2,$db);

}catch (Exception $e)
{
    switch ($e->getCode()) {
        case 23000:
            echo '<h4>Der Straßenname existiert bereits!</h4>';
            break;
        
        default:
            echo 'Error - Strasse: '.$e->getCode().': '.$e->getMessage().'<br>';
            break;
    }
}
}else if(isset($_POST['describe']))
{//Daten Speichern
$db=$_POST['db'];
$table=$_POST['table'];

$query1='use '.$db;
$query2='describe '.$table;

try
{
    $stmt=makeStatement($query1);
    makeTable($query2);

}catch (Exception $e)
{
    switch ($e->getCode()) {
        case 23000:
            echo '<h4>Der Straßenname existiert bereits!</h4>';
            break;
        
        default:
            echo 'Error - Strasse: '.$e->getCode().': '.$e->getMessage().'<br>';
            break;
    }
}
}else if(isset($_POST['content']))
{//Daten Speichern
    $db=$_POST['db'];
    $table=$_POST['table'];
    
    $query1='use '.$db;
    $query2='select * from '.$table;
    
try
{
    $stmt=makeStatement($query1);
    makeTable($query2);

}catch (Exception $e)
{
    switch ($e->getCode()) {
        case 23000:
            echo '<h4>Der Straßenname existiert bereits!</h4>';
            break;
        
        default:
            echo 'Error - Strasse: '.$e->getCode().': '.$e->getMessage().'<br>';
            break;
    }
}
}else
{//formular anzeigen
    ?>
    <form method="post">
    <?php
    echo '<h1>Adresse</h1>';
    $query= 'show databases';
    
    makeTablewithButton($query);
    ?>
    </form>
    <?php

}